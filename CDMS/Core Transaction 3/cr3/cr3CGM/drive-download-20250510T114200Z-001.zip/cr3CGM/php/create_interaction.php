<?php
include("connection.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get and sanitize input
    $guest_id = isset($_POST['GuestID']) ? intval($_POST['GuestID']) : 0;
    $interaction_type = isset($_POST['interaction_type']) ? trim($_POST['interaction_type']) : '';
    $comment = isset($_POST['comment']) ? trim($_POST['comment']) : '';
    $status = isset($_POST['status']) ? trim($_POST['status']) : '';

    // Validation
    if ($guest_id <= 0 || empty($interaction_type) || empty($comment) || empty($status)) {
        echo "Invalid input. Please fill all required fields.";
        exit;
    }

    try {
        // Insert into database
        $stmt = $conn->prepare("INSERT INTO interactions (GuestID, interaction_type, description, interaction_status, interaction_date) VALUES (?, ?, ?, ?, NOW())");

        $stmt->bindParam(1, $guest_id, PDO::PARAM_INT);
        $stmt->bindParam(2, $interaction_type, PDO::PARAM_STR);
        $stmt->bindParam(3, $comment, PDO::PARAM_STR);
        $stmt->bindParam(4, $status, PDO::PARAM_STR);

        if ($stmt->execute()) {
            // Redirect on success
            header("Location: ../interactions.php");
            exit;
        } else {
            // Display error message
            echo "Error inserting data: " . implode(" | ", $stmt->errorInfo());
            header("Location: ../interactions.php");
        }
    } catch (PDOException $e) {
        echo "Database error: " . $e->getMessage();
        header("Location: ../interactions.php");
    }
} else {
    echo "Invalid request method.";
    header("Location: ../interactions.php");
}
?>
