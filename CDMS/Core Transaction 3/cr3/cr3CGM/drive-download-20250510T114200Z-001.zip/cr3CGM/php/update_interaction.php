<?php
// Include your database connection
include('connection.php');

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the InteractionID and new status from the POST request
    $interactionID = $_POST['InteractionID'];
    $status = $_POST['status'];

    // Prepare the SQL query to update the status
    $query = "UPDATE interactions SET interaction_status = :status WHERE InteractionID = :interactionID";

    try {
        // Prepare the PDO statement
        $stmt = $conn->prepare($query);
        
        // Bind the parameters
        $stmt->bindParam(':status', $status, PDO::PARAM_STR);
        $stmt->bindParam(':interactionID', $interactionID, PDO::PARAM_INT);

        // Execute the query
        $stmt->execute();

      
        header("Location: ../interactions.php");
    } catch (PDOException $e) {
        // If there is an error, display an error message
        
         header("Location: ../interactions.php");
    }
}
?>