<?php
require 'connection.php';

$guestID = $_GET['guest_id'] ?? '';
$guestName = $_GET['name'] ?? '';

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $guestID = $_POST['guest_id'] ?? '';
    $rating = $_POST['rating'] ?? '';
    $comment = $_POST['comment'] ?? '';
    $guestName = $_POST['guest_name'] ?? ''; // Keep guest name after submission

    if (!empty($guestID) && !empty($rating) && !empty($comment)) {
        try {
            $stmt = $conn->prepare("INSERT INTO feedback (GuestID, rating, comment, feedback_date) VALUES (:guestID, :rating, :comment, NOW())");
            $stmt->bindParam(':guestID', $guestID);
            $stmt->bindParam(':rating', $rating);
            $stmt->bindParam(':comment', $comment);
            $stmt->execute();
        
            echo "<script>alert('Thank you for your feedback!');</script>";
             header("Location: ../history_feedback.php");
        } catch (PDOException $e) {
            echo "<script>alert('Error saving feedback: " . $e->getMessage() . "');</script>";
        }
    } else {
        echo "<script>alert('Please complete all fields.');</script>";
    }
}
?>