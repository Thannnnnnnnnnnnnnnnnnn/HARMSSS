<?php
include("connection.php");

if($_SERVER['REQUEST_METHOD'] =="POST") {

    $guest_name = $_POST['guest_name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $birthday = $_POST['birthday'];
    $gender = $_POST['gender'];
    $nationality = $_POST['nationality'] ?? '';
    $room = $_POST['room'];
    $check_in = $_POST['check_in'];

    try {
    
        // SQL query to insert guest data
        $sql = "INSERT INTO guests (guest_name, email, phone, address, date_of_birth, gender, nationality, reservation, check_in)
                VALUES (:guest_name, :email, :phone, :address, :birthday, :gender, :nationality, :room, :check_in)";
    
        // Prepare the query
        $stmt = $conn->prepare($sql);
    
        // Bind parameters to the prepared statement
        $stmt->bindParam(':guest_name', $guest_name);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':phone', $phone);
        $stmt->bindParam(':address', $address);
        $stmt->bindParam(':birthday', $birthday);
        $stmt->bindParam(':gender', $gender);
        $stmt->bindParam(':nationality', $nationality);
        $stmt->bindParam(':room', $room);
        $stmt->bindParam(':check_in', $check_in);
    
        // Execute the query
        $stmt->execute();
    
        // Redirect to another page after successful submission (e.g., a confirmation page)
        header("Location: ../guest.php"); // Redirect to success_page.php (change URL as needed)
        exit(); // Make sure no further code is executed after the redirect
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}
?>