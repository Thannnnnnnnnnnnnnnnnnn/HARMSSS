<?php
include("connection.php");

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['GuestID'])) {
    $guestID = $_POST['GuestID'];

    try {
        // Start transaction
        $conn->beginTransaction();

        // 1. Delete from interactions table
        $stmt1 = $conn->prepare("DELETE FROM interactions WHERE GuestID = :GuestID");
        $stmt1->execute([':GuestID' => $guestID]);

        // 2. Delete from feedback table
        $stmt2 = $conn->prepare("DELETE FROM feedback WHERE GuestID = :GuestID");
        $stmt2->execute([':GuestID' => $guestID]);

        // 3. Delete from guests table
        $stmt3 = $conn->prepare("DELETE FROM guests WHERE GuestID = :GuestID");
        $stmt3->execute([':GuestID' => $guestID]);

        // Commit changes
        $conn->commit();

        header("Location: ../guest.php?msg=deleted");
        exit;
    } catch (PDOException $e) {
        // Rollback if error occurs
        $conn->rollBack();
        echo "Error deleting guest: " . $e->getMessage();
    }
} else {
    header("Location: ../guest.php?msg=invalid_request");
    exit;
}
?>