<?php
require 'connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['FeedbackID'])) {
    try {
        $FeedbackID = intval($_POST['FeedbackID']);

        $stmt = $conn->prepare("DELETE FROM feedback WHERE FeedbackID = :feedback_id");
        $stmt->bindValue(':feedback_id', $FeedbackID, PDO::PARAM_INT);

        if ($stmt->execute()) {
            echo "<script>alert('Feedback deleted successfully!'); window.location.href='../history_feedback.php';</script>";
        } else {
            echo "<script>alert('Error deleting feedback!'); window.location.href='../history_feedback.php';</script>";
        }

    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
} else {
    header("Location: ../history_feedback.php");
    exit();
}
?>