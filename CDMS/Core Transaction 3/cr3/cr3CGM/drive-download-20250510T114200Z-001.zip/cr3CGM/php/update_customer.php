<?php
require 'connection.php'; // Your PDO connection setup

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get submitted data safely
    $guestId = intval($_POST['GuestID'] ?? 0);
    $userId = intval($_POST['user_id'] ?? 0);

    $name = $_POST['guest_name'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $address = $_POST['address'] ?? '';
    $birthday = $_POST['date_of_birth'] ?? '';
    $email = $_POST['email'] ?? '';
    $gender = $_POST['gender'] ?? '';
    $nationality = $_POST['nationality'] ?? '';

    // You might want to add validation here before proceeding

    try {
        if ($guestId > 0) {
            // Update existing guest record
            $stmt = $conn->prepare("UPDATE guests 
                SET guest_name = :guest_name, phone = :phone, address = :address,
                    date_of_birth = :date_of_birth, email = :email, gender = :gender,
                    nationality = :nationality
                WHERE GuestID = :guestId");
            $stmt->bindParam(':guestId', $guestId, PDO::PARAM_INT);
        } else {
            // Insert new guest record with user_id
            $stmt = $conn->prepare("INSERT INTO guests 
                (user_id, guest_name, phone, address, date_of_birth, email, gender, nationality)
                VALUES
                (:user_id, :guest_name, :phone, :address, :date_of_birth, :email, :gender, :nationality)");
            $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
        }

        // Bind common parameters
        $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
        $stmt->bindParam(':guest_name', $name);
        $stmt->bindParam(':phone', $phone);
        $stmt->bindParam(':address', $address);
        $stmt->bindParam(':date_of_birth', $birthday);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':gender', $gender);
        $stmt->bindParam(':nationality', $nationality);
        

        $stmt->execute();

        // Redirect after success
        header("Location: ../guest.php?success=1");
        exit;
    } catch (PDOException $e) {
        echo "Database error: " . $e->getMessage();
        // You might want to log the error and show user-friendly message instead
    }
} else {
    // If accessed not via POST, optionally redirect or show error
    header("Location: ../guest.php");
    exit;
}
