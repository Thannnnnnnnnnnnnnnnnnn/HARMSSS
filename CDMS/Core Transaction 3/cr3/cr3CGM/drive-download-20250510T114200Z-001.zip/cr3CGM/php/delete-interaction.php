<?php
// Start session if using session-based messages (optional)
// session_start();

// Include your database connection
include("connection.php");// Adjust the path if needed

// Check if the interaction ID is posted
if (isset($_POST['interaction_id'])) {
    $interactionID = $_POST['interaction_id'];

    try {
        // Prepare and execute the DELETE query using PDO
        $stmt = $conn->prepare("DELETE FROM interactions WHERE InteractionID = :interaction_id");
        $stmt->bindParam(':interaction_id', $interactionID, PDO::PARAM_INT);
        $stmt->execute();

        // Redirect after successful deletion
        header("Location: ../interactions.php"); // Adjust path if needed
        exit();
    } catch (PDOException $e) {
        echo "Error deleting interaction: " . $e->getMessage();
    }
} else {
    echo "Invalid request.";
}
?>