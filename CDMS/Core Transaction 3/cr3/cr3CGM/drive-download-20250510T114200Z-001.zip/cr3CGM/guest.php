<?php
session_start();
require_once __DIR__ . '/../functions.php';
$user = $_SESSION['user'];
$_SESSION['user_id'] = $user['user_id'];
?>


<!DOCTYPE html>
<html lang="en">
<head>                                               
<?php include 'header.php';?>
</head>
<body>
 <!-- For Manager Staff and Admin  --> 
    <div class="flex min-h-screen w-full">
    
<?php include __DIR__ . '/../partials/admin/sidebar.php';?>
<?php include __DIR__ . '/../partials/admin/navbar.php';?>


            <!-- Main Content -->
            <main class="px-8 py-8">
             
    <?php if ( $user['role'] === 'admin' || $user['role'] === 'manager' || $user['role'] === 'staff' ): ?>        
            <h2 class="text-center text-2xl font-bold text-gray-800 mb-4">Guest Table</h2>    

            <div class="flex flex-wrap gap-4 justify-center">

  <!-- Stats Section -->
  
<section class="flex justify-center gap-6 mb-8 overflow-x-auto">
  <?php
    include 'php/connection.php';

    // Count total checked-out guests
    $stmt = $conn->query("SELECT COUNT(*) FROM guests WHERE check_out IS NOT NULL");
    $totalGuests = $stmt->fetchColumn();

    // Count total interactions
    $stmt = $conn->query("SELECT COUNT(*) FROM interactions");
    $totalInteractions = $stmt->fetchColumn();

    // Count total feedbacks
    $stmt = $conn->query("SELECT COUNT(*) FROM feedback");
    $totalFeedbacks = $stmt->fetchColumn();

    // Count total active users
    $stmt = $conn->query("SELECT COUNT(*) FROM guests WHERE status = 'active'");
    $totalActiveUsers = $stmt->fetchColumn();
  ?>

  <!-- Total Guests Card -->
  <div class="bg-white p-6 w-[250px] rounded-2xl border border-[#594423] shadow-md flex items-center gap-4">
    <div class="bg-[#F7E6CA] p-3 rounded-full">
      <i class="bx bx-user text-2xl"></i>
    </div>
    <div>
      <p class="text-sm text-[#6B4F38]">Total Guests</p>
      <p class="text-2xl font-bold"><?php echo $totalGuests; ?></p>
    </div>
  </div>

  <!-- Interactions Card -->
  <div class="bg-white p-6 w-[250px] rounded-2xl border border-[#594423] shadow-md flex items-center gap-4">
    <div class="bg-[#F7E6CA] p-3 rounded-full">
      <i class="bx bx-message-square-detail text-2xl"></i>
    </div>
    <div>
      <p class="text-sm text-[#6B4F38]">Interactions</p>
      <p class="text-2xl font-bold"><?php echo $totalInteractions; ?></p>
    </div>
  </div>

  <!-- Feedbacks Card -->
  <div class="bg-white p-6 w-[250px] rounded-2xl border border-[#594423] shadow-md flex items-center gap-4">
    <div class="bg-[#F7E6CA] p-3 rounded-full">
      <i class="bx bx-star text-2xl"></i>
    </div>
    <div>
      <p class="text-sm text-[#6B4F38]">Feedbacks</p>
      <p class="text-2xl font-bold"><?php echo $totalFeedbacks; ?></p>
    </div>
  </div>

</section>



  </div>

  

<div class="overflow-x-auto rounded-2xl shadow-md bg-white p-4">
<div class="grid grid-flow-col auto-cols-max gap-4">

<!-- Button to Open Modal -->
<button 
    class="bg-[#F7E6CA] text-[#4E3B2A] rounded-md px-4 py-2 hover:bg-[#594423] hover:text-white transition checkout-btn m-2"
    data-bs-toggle="modal"
    data-bs-target="#registerGuestModal">
    + Register New Guest
</button>

<!-- Register Guest Modal -->
<div class="modal fade" id="registerGuestModal" tabindex="-1" aria-labelledby="registerGuestModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
    
      <div class="modal-header">
        <h5 class="modal-title" id="registerGuestModalLabel">Register New Guest</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

      <form action="php/add_guest.php" method="POST">
        <div class="modal-body">
          <div class="mb-3">
            <label for="guest_name" class="form-label">Guest Name</label>
            <input type="text" class="form-control" id="guest_name" name="guest_name" required>
          </div>

          <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" class="form-control" id="email" name="email" required>
          </div>

          <div class="mb-3">
            <label for="phone" class="form-label">Phone</label>
            <input type="tel" class="form-control" id="phone" name="phone" required>
          </div>

          <div class="mb-3">
            <label for="address" class="form-label">Address</label>
            <input type="text" class="form-control" id="address" name="address" required>
          </div>

          <div class="mb-3">
            <label for="birthday" class="form-label">Birthday</label>
            <input type="date" class="form-control" id="birthday" name="birthday" required>
          </div>

          <div class="mb-3">
            <label for="gender" class="form-label">Gender</label>
            <input type="text" class="form-control" id="gender" name="gender" required>
          </div>

          <div class="mb-3">
            <label for="nationality" class="form-label">Nationality</label>
            <input type="text" class="form-control" id="nationality" name="nationality" required>
          </div>

          <div class="mb-3">
            <label for="room" class="form-label">Room</label>
            <input type="text" class="form-control" id="room" name="room" required>
          </div>

          <div class="mb-3">
            <label for="editCheckin" class="form-label">Check-in</label>
            <input type="datetime-local" class="form-control" id="check-in" name="check_in" >
         </div>

          
        </div>

        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Save Guest</button>
        </div>
      </form>

    </div>
  </div>
</div>


<input type="text" 
    class="bg-[#FFF6E8] h-10 rounded-lg grow w-[570px] pl-10 pr-4 focus:ring-2 focus:ring-[#F7E6CA] focus:outline-none mt-[7px] " 
    placeholder="Search something..." 
    aria-label="Search input"
    id="searchInput"/>
    
    <i class="fa-solid fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-[#4E3B2A]"></i>
</div>                   


  <table id="customerTable" class="min-w-full text-sm text-left text-gray-700">
  <thead class="bg-white text-[#4E3B2A] text-base border-b divide-gray-200">
      <tr>
        <th class="px-6 py-1">Guest ID</th>
        <th class="px-6 py-1">Guest Name</th>
        <th class="px-6 py-1">Email</th>
        <th class="px-6 py-1">Contact</th>
        <th class="px-6 py-1">Action</th>
      </tr>
    </thead>
    <tbody id="guestTbody" class="text-gray-800 divide-y divide-gray-200">
      <?php 
  
   $stmt = $conn->prepare("SELECT * FROM guests WHERE check_out IS NULL OR check_out = ''");
   $stmt->execute();
   $guests = $stmt->fetchAll(PDO::FETCH_ASSOC);

      ?>
      <?php foreach ($guests as $guests): ?>
        <tr class="hover:bg-gray-100 transition">
          <td class="px-6 py-1"><?php echo htmlspecialchars($guests['GuestID']); ?></td>
          <td class="px-6 py-1"><?php echo htmlspecialchars($guests['guest_name']); ?></td>
          <td class="px-6 py-1"><?php echo htmlspecialchars($guests['email']); ?></td>
          <td class="px-6 py-1"><?php echo htmlspecialchars($guests['phone']); ?></td>
          <td class="px-6 py-1 space-x-1 flex flex-wrap gap-1">

          <div class="flex justify-center gap-1 mb-6">

            <!-- View Button -->
            <a href="#"
              class="bg-blue-600 text-white px-3 py-2 rounded-lg hover:bg-blue-700 view-btn"
              data-bs-toggle="modal"
              data-bs-target="#viewModal"
              data-id="<?php echo $guests['GuestID']; ?>"
              data-name="<?php echo htmlspecialchars($guests['guest_name']); ?>"
              data-email="<?php echo htmlspecialchars($guests['email']); ?>"
              data-phone="<?php echo htmlspecialchars($guests['phone']); ?>"
              data-address="<?php echo htmlspecialchars($guests['address']); ?>"
              data-birthday="<?php echo htmlspecialchars($guests['date_of_birth']); ?>"
              data-gender="<?php echo htmlspecialchars($guests['gender']); ?>"
              data-nationality="<?php echo htmlspecialchars($guests['nationality']); ?>"
              data-reservation="<?php echo htmlspecialchars($guests['reservation']); ?>"
              data-checkin="<?php echo htmlspecialchars($guests['check_in']); ?>"
              data-checkout="<?php echo htmlspecialchars($guests['check_out']); ?>"
              data-status="<?php echo htmlspecialchars($guests['status']); ?>">
              <i class="bx bx-show"></i>
            </a>

           
            <!-- Edit Button -->
            <a href="#"
              class="bg-green-500 text-white px-3 py-2 rounded-lg hover:bg-green-600 edit-btn"
              data-bs-toggle="modal"
              data-bs-target="#editModal"
              data-guest-id="<?php echo $guests['GuestID']; ?>"
              data-name="<?php echo $guests['guest_name']; ?>"
              data-email="<?php echo $guests['email']; ?>"
              data-phone="<?php echo $guests['phone']; ?>"
              data-address="<?php echo $guests['address']; ?>"
              data-birthday="<?php echo date('Y-m-d', strtotime($guests['date_of_birth'])); ?>"
              data-checkin="<?php echo date('Y-m-d', strtotime($guests['check_in'])); ?>"
              data-checkout="<?php echo date('Y-m-d', strtotime($guests['check_out'])); ?>"
              data-gender="<?php echo $guests['gender']; ?>"
              data-nationality="<?php echo $guests['nationality']; ?>"
              data-reservation="<?php echo $guests['reservation']; ?>"
              data-status="<?php echo $guests['status']; ?>">
              <i class="bx bx-edit"></i>
            </a>

           <!-- Delete Button -->
<button type="button"
    onclick="openGuestDeleteModal('<?php echo $guests['GuestID']; ?>', '<?php echo htmlspecialchars($guests['guest_name'], ENT_QUOTES); ?>')"
    class="bg-red-500 text-white px-3 py-2 rounded-lg hover:bg-red-600">
    <i class="bx bx-trash"></i>
</button>
      </div>


      
          

          
          </td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>

  <!-- No Guests Message -->
  <div id="noGuestsMessage" class="text-center text-gray-500 py-4 hidden">
    No guests are currently checked in.
  </div>
</div>


             <!-- Modal Area -->

              <!-- View Modal -->
<div class="modal fade" id="viewModal" tabindex="-1" aria-labelledby="modalTitle" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalTitle">Guest Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p><strong>Guest ID:</strong> <span id="guestId"></span></p>
                <p><strong>Name:</strong> <span id="guestName"></span></p>
                <p><strong>Email:</strong> <span id="guestEmail"></span></p>
                <p><strong>Phone:</strong> <span id="guestPhone"></span></p>
                <p><strong>Address:</strong> <span id="guestAddress"></span></p>
                <p><strong>Birthday:</strong> <span id="guestBirthday"></span></p>
                <p><strong>Gender:</strong> <span id="guestGender"></span></p>
                <p><strong>Nationality:</strong> <span id="guestNationality"></span></p>
                <p><strong>Reservation	:</strong> <span id="guestReservation"></span></p>
            </div>
        </div>
    </div>
</div>

  <!-- Edit Modal -->
<div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editModalLabel">Edit Guest</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="php/update_guest.php" method="POST" enctype="multipart/form-data">
                <div class="modal-body">
                    <!-- Hidden Field for ID -->
                    <input type="hidden" id="editGuestId" name="GuestID">

                    <div class="mb-3">
                        <label for="editGuestName" class="form-label">Name</label>
                        <input type="text" class="form-control" id="editName" name="guest_name" >
                    </div>

                    <div class="mb-3">
                        <label for="editEmail" class="form-label">Email</label>
                        <input type="email" class="form-control" id="editEmail" name="email" >
                    </div>

                    <div class="mb-3">
                        <label for="editPhone" class="form-label">Phone</label>
                        <input type="text" class="form-control" id="editPhone" name="phone" >
                    </div>

                    <div class="mb-3">
                        <label for="editAddress" class="form-label">Address</label>
                        <textarea class="form-control" id="editAddress" name="address" rows="3" ></textarea>
                    </div>

                    <div class="mb-3">
                        <label for="editBirthday" class="form-label">Birthday</label>
                        <input type="date" class="form-control" id="editBirthday" name="date_of_birth" >
                    </div>

                    <div class="mb-3">
                        <label for="editGender" class="form-label">Gender</label>
                        <input type="text" class="form-control" id="editGender" name="gender" >
                    </div>

                    <div class="mb-3">
                        <label for="editNationality" class="form-label">Nationality</label>
                        <input type="text" class="form-control" id="editNationality" name="nationality" >
                    </div>

                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

 <!-- Delete Confirmation Modal for Guest -->
<div id="guestDeleteModal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center hidden z-50">
    <div class="bg-white p-6 rounded-lg shadow-lg w-[350px] text-center">
        <h2 class="text-xl font-bold mb-4">Confirm Deletion</h2>
        <p class="mb-4">
            Are you sure you want to delete guest <strong id="deleteGuestName"></strong>
            (ID: <strong id="deleteGuestID"></strong>)?
        </p>

        <!-- Delete Form -->
        <form id="guestDeleteForm" action="php/delete.php" method="POST">
            <input type="hidden" name="GuestID" id="guestID">
            <div class="flex justify-center space-x-4">
                <button type="button" onclick="closeGuestModal()" class="bg-gray-400 text-white px-4 py-2 rounded-lg">
                    Cancel
                </button>
                <button type="submit" class="bg-red-500 text-white px-4 py-2 rounded-lg">
                    Delete
                </button>
            </div>
        </form>
    </div>
</div>

<!-- End of Modal Area  -->
<?php endif; ?>
<!-- For Manager Staff and Admin  --> 

      
<!-- For Guest  --> 
 <?php if ( $user['role'] === 'guest' ): ?>

  <div class="max-w-3xl mx-auto mt-10 bg-white border border-[#594423] rounded-[12px] shadow-md p-6">
  <h2 class="text-xl font-semibold text-[#4E3B2A] mb-4 text-center">My Information</h2>
  <?php

// Make sure the database connection $conn is established

$userId = $_SESSION['user_id'];

// Include DB connection
include('php/connection.php');

// Prepare the SQL query with a placeholder
$sqlGuestInfo = "SELECT * FROM guests WHERE user_id = ?";

$stmtGuestInfo = $conn->prepare($sqlGuestInfo);
$stmtGuestInfo->bindParam(1, $userId, PDO::PARAM_INT);
$stmtGuestInfo->execute();
$guest = $stmtGuestInfo->fetch(PDO::FETCH_ASSOC);

?>


  <form class="space-y-4 text-sm" method="POST" action="php/update_customer.php">
    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
      <input type="hidden" name="GuestID" value="<?php echo htmlspecialchars($guest['GuestID']); ?>">
       <input type="hidden" name="user_id" value="<?php echo htmlspecialchars($userId)?>">
      <!-- Full Name -->
      <div>
        <label class="block font-medium mb-1">Full Name</label>
        <input type="text" name="guest_name" value="<?php echo htmlspecialchars($guest['guest_name']); ?>"
               class="w-full border border-[#594423] rounded-[10px] p-2 focus:outline-none focus:ring-2 focus:ring-[#F7E6CA]"
               required>
      </div>

      <!-- Email -->
      <div>
        <label class="block font-medium mb-1">Email</label>
        <input type="email" name="email" value="<?php echo htmlspecialchars($guest['email']); ?>"
               class="w-full border border-[#594423] rounded-[10px] p-2 focus:outline-none focus:ring-2 focus:ring-[#F7E6CA]"
               required>
      </div>

      <!-- Phone -->
      <div>
        <label class="block font-medium mb-1">Phone Number</label>
        <input type="text" name="phone" value="<?php echo htmlspecialchars($guest['phone']); ?>"
               class="w-full border border-[#594423] rounded-[10px] p-2 focus:outline-none focus:ring-2 focus:ring-[#F7E6CA]"
               required>
      </div>

      <!-- Address -->
      <div>
        <label class="block font-medium mb-1">Address</label>
        <input type="text" name="address" value="<?php echo htmlspecialchars($guest['address']); ?>"
               class="w-full border border-[#594423] rounded-[10px] p-2 focus:outline-none focus:ring-2 focus:ring-[#F7E6CA]"
               required>
      </div>

<!-- Gender -->
<div>
  <label class="block font-medium mb-1">Gender</label>
  <select name="gender"
          class="w-full border border-[#594423] rounded-[10px] p-2 focus:outline-none focus:ring-2 focus:ring-[#F7E6CA]"
          required>
    <option disabled <?php if (!isset($guest['gender'])) echo 'selected'; ?>>Select Gender</option>
    <option value="Male" <?php if (isset($guest['gender']) && $guest['gender'] == 'Male') echo 'selected'; ?>>Male</option>
    <option value="Female" <?php if (isset($guest['gender']) && $guest['gender'] == 'Female') echo 'selected'; ?>>Female</option>
    <option value="Other" <?php if (isset($guest['gender']) && $guest['gender'] == 'Other') echo 'selected'; ?>>Other</option>
  </select>
</div>

      <!-- Date of Birth -->
<div>
  <label class="block font-medium mb-1">Date of Birth</label>
  <input type="date" name="date_of_birth" value="<?php echo htmlspecialchars($guest['date_of_birth']); ?>"
         class="w-full border border-[#594423] rounded-[10px] p-2 focus:outline-none focus:ring-2 focus:ring-[#F7E6CA]"
         required>
</div>


      <!-- Nationality -->
      <div class="md:col-span-2">
        <label class="block font-medium mb-1">Nationality</label>
        <input type="text" name="nationality" value="<?php echo htmlspecialchars($guest['nationality']); ?>"
               class="w-full border border-[#594423] rounded-[10px] p-2 focus:outline-none focus:ring-2 focus:ring-[#F7E6CA]"
               required>
      </div>
    </div>

    <!-- Submit Button -->
    <div class="flex justify-center pt-4">
      <button type="submit"
              class="bg-[#F7E6CA] text-[#4E3B2A] px-5 py-2 rounded-[8px] border border-[#594423] transition hover:bg-[#e4d3b4] active:scale-95">
        Save Changes
      </button>
    </div>
  </form>
</div>


   <?php endif; ?>

 <!-- For Guest Page -->



   </div>

         </main>
    </div>

   
    
    <?php include 'footer.php';?>
</body>
</html>
